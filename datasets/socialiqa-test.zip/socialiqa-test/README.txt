This zip file contains the test questions for the AI2 leaderboard https://leaderboard.allenai.org/socialiqa
